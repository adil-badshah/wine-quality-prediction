# wine-quality-classification-using-SVC-model
